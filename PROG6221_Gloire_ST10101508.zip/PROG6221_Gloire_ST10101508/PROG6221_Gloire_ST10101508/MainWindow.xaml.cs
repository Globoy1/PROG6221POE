﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROG6221_Gloire_ST10101508
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes;

        public MainWindow()
        {
            InitializeComponent();
            recipes = new List<Recipe>();
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text;
            string ingredients = txtIngredients.Text;
            string foodGroup = txtFoodGroup.Text;
            string steps = txtSteps.Text;
            int maxCalories = (int)sliderMaxCalories.Value;

            Recipe recipe = new Recipe(name, ingredients, foodGroup, steps, maxCalories);
            recipes.Add(recipe);

            RefreshRecipeList();
        }

        private void DeleteRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (listRecipes.SelectedItem != null)
            {
                Recipe selectedRecipe = (Recipe)listRecipes.SelectedItem;
                recipes.Remove(selectedRecipe);
                RefreshRecipeList();
                txtRecipeDetails.Text = "";
            }
        }

        private void listRecipes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listRecipes.SelectedItem != null)
            {
                Recipe selectedRecipe = (Recipe)listRecipes.SelectedItem;
                txtRecipeDetails.Text = $"Recipe Name: {selectedRecipe.Name}\nIngredients: {selectedRecipe.Ingredients}\nFood Group: {selectedRecipe.FoodGroup}\nSteps: {selectedRecipe.Steps}\nMax Calories: {selectedRecipe.MaxCalories}";
                MessageBox.Show($"Recipe Name: {selectedRecipe.Name}\n\nIngredients:\n{string.Join(", ", selectedRecipe.Ingredients)}\n\nSteps:\n{string.Join("\n", selectedRecipe.Steps)}\n\nFoodGroup:\n{string.Join("\n", selectedRecipe.FoodGroup)}\n\nMaxCalories:\n{string.Join("\n", selectedRecipe.MaxCalories)}", "Recipe Details");
            }
        }

        private void RefreshRecipeList()
        {
            listRecipes.ItemsSource = null;
            listRecipes.ItemsSource = recipes.OrderBy(r => r.Name);
        }

    }

    public class Recipe
    {
        public string Name { get; set; }
        public string Ingredients { get; set; }
        public string FoodGroup { get; set; }
        public string Steps { get; set; }
        public int MaxCalories { get; set; }

        public Recipe(string name, string ingredients, string foodGroup, string steps, int maxCalories)
        {
            Name = name;
            Ingredients = ingredients;
            FoodGroup = foodGroup;
            Steps = steps;
            MaxCalories = maxCalories;
        }
    }
}